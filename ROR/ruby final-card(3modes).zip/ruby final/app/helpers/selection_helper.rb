module SelectionHelper
end
