class CardselectionController < ApplicationController
    def game
    end
end
