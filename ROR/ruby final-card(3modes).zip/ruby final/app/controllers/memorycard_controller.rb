class MemorycardController < ApplicationController
    def card
    end
    
    def num
    end
    
    def alpha
    end

end
