class MatrixController < ApplicationController
    def matrix
    end

end
