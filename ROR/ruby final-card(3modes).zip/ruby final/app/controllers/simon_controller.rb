class SimonController < ApplicationController
    def simon
    end
end
