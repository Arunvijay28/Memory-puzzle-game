class SelectionController < ApplicationController
    def index
    end
end
