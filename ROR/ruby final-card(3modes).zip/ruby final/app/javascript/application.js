import "@hotwired/turbo-rails"
import "controllers"
import "app\javascript\signup.js"